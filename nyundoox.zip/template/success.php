
<div class="content-wrapper">
    <h1>New record created successfully.</h1>
</div>