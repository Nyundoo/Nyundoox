<div class="content-wrapper">
    <h1>Record deleted successfully.</h1>
</div>